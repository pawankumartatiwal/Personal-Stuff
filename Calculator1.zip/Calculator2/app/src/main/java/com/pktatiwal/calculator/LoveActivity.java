package com.pktatiwal.calculator;

import android.os.Bundle;
import android.view.Gravity;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class LoveActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView tv = new TextView(this);
        tv.setText("I Love you My Dear Sakshi ji ❤️");
        tv.setTextSize(28);
        tv.setGravity(Gravity.CENTER);
        tv.setBackgroundColor(0xFF000000);
        tv.setTextColor(0xFFFFFFFF);

        setContentView(tv);
    }
}
