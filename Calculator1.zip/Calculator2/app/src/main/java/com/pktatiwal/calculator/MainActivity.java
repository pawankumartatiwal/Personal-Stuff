package com.pktatiwal.calculator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView expressionView, resultView;
    private String expression = "";
    private boolean isDegree = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        expressionView = findViewById(R.id.expressionView);
        resultView = findViewById(R.id.resultView);

        restoreState(savedInstanceState);
        setupEqualsLongPress();
    }

    // =========================
    // SAVE STATE (FIX FOR MINIMIZE RESET)
    // =========================
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("expr", expression);
        outState.putString("result", resultView.getText().toString());
        outState.putBoolean("degMode", isDegree);
    }

    private void restoreState(Bundle savedInstanceState) {
        if (savedInstanceState == null) return;

        expression = savedInstanceState.getString("expr", "");
        String result = savedInstanceState.getString("result", "");
        isDegree = savedInstanceState.getBoolean("degMode", true);

        expressionView.setText(expression);
        resultView.setText(result);

        Button modeBtn = findViewById(R.id.button_deg);
        if (modeBtn != null) {
            modeBtn.setText(isDegree ? "DEG" : "RAD");
        }
    }

    // =========================
    // INPUT
    // =========================
    public void onButtonClick(View v) {
        String val = ((Button)v).getText().toString();

        switch (val) {
            case "π": expression += Math.PI; break;
            case "e": expression += Math.E; break;
            case "sin":
            case "cos":
            case "tan":
            case "log":
            case "ln":
            case "√":
                expression += val + "(";
                break;
            default:
                expression += val;
        }

        expressionView.setText(expression);
    }

    public void onClear(View v) {
        expression = "";
        expressionView.setText("");
        resultView.setText("");
    }

    public void onBackspace(View v) {
        if (!expression.isEmpty()) {
            expression = expression.substring(0, expression.length() - 1);
            expressionView.setText(expression);
        }
    }

    public void onToggleMode(View v) {
        isDegree = !isDegree;
        ((Button)v).setText(isDegree ? "DEG" : "RAD");
    }

    public void onEquals(View v) {
        calculate();
    }

    // =========================
    // SECRET LONG PRESS
    // Hold "=" for 3 seconds
    // =========================
    private void setupEqualsLongPress() {
        Button eq = findViewById(R.id.button_equals);
        if (eq == null) return;

        eq.setOnLongClickListener(v -> {
            if (expression.equals("1*4*3")) {
                startActivity(new Intent(MainActivity.this, LoveActivity.class));
            }
            return true;
        });
    }

    // =========================
    // CALCULATION
    // =========================
    private void calculate() {
        try {
            double result = eval(expression);
            String out = format(result);

            resultView.setText(out);
            expression = out;
            expressionView.setText(expression);

        } catch (Exception e) {
            resultView.setText("Error");
        }
    }

    // =========================
    // PARSER ENGINE
    // =========================
    private double eval(final String str) {
        return new Object() {
            int pos = -1, ch;

            void nextChar() {
                ch = (++pos < str.length()) ? str.charAt(pos) : -1;
            }

            boolean eat(int charToEat) {
                while (ch == ' ') nextChar();
                if (ch == charToEat) {
                    nextChar();
                    return true;
                }
                return false;
            }

            double parse() {
                nextChar();
                double x = parseExpression();
                if (pos < str.length()) throw new RuntimeException("Invalid");
                return x;
            }

            double parseExpression() {
                double x = parseTerm();
                for (;;) {
                    if (eat('+')) x += parseTerm();
                    else if (eat('-')) x -= parseTerm();
                    else return x;
                }
            }

            double parseTerm() {
                double x = parseFactor();
                for (;;) {
                    if (eat('*')) x *= parseFactor();
                    else if (eat('/')) x /= parseFactor();
                    else return x;
                }
            }

            double parseFactor() {
                if (eat('+')) return parseFactor();
                if (eat('-')) return -parseFactor();

                double x;
                int startPos = this.pos;

                if (eat('(')) {
                    x = parseExpression();
                    eat(')');
                }
                else if ((ch >= '0' && ch <= '9') || ch == '.') {
                    while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                    x = Double.parseDouble(str.substring(startPos, this.pos));
                }
                else if (ch >= 'a' && ch <= 'z' || ch == '√') {
                    while (ch >= 'a' && ch <= 'z' || ch == '√') nextChar();
                    String func = str.substring(startPos, this.pos);
                    x = parseFactor();
                    x = applyFunc(func, x);
                }
                else {
                    throw new RuntimeException("Unexpected");
                }

                if (eat('^')) x = Math.pow(x, parseFactor());
                return x;
            }
        }.parse();
    }

    private double applyFunc(String func, double x) {
        switch (func) {
            case "√": return Math.sqrt(x);
            case "sin": return isDegree ? Math.sin(Math.toRadians(x)) : Math.sin(x);
            case "cos": return isDegree ? Math.cos(Math.toRadians(x)) : Math.cos(x);
            case "tan": return isDegree ? Math.tan(Math.toRadians(x)) : Math.tan(x);
            case "log": return Math.log10(x);
            case "ln": return Math.log(x);
        }
        throw new RuntimeException("Unknown function");
    }

    private String format(double val) {
        if (val == (long) val) return String.valueOf((long) val);
        return String.valueOf(val);
    }
}
